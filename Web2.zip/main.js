    var app = new Vue({
    el: "#app",
    data:{
        account: "Guest",
    },
    methods:{
        currentDate: function() {
            var t = new Date().toLocaleDateString();
            time = t
            return time;
        }
    }
})

const app2 = new Vue({ 
    el:"#timeApp",
    data:{
        timer:null,
        totalTime:(25*60),
        resetButton: false,
        title:"Start studying!"
    },
    methods: {
        startTimer: function() {
          this.timer = setInterval(() => this.countdown(), 1000);
          this.resetButton = true;
          this.title = "Start your studying!"
        },
        stopTimer: function() {
          clearInterval(this.timer);
          this.timer = null;
          this.resetButton = true;
          this.title = "Lets keep going don't stop!"
        },
        resetTimer: function() {
          this.totalTime = (25 * 60);
          clearInterval(this.timer);
          this.timer = null;
          this.resetButton = false;
          this.title = "Lets go!"
        },
        padTime: function(time) {
          return (time < 10 ? '0' : '') + time;
        },
        countdown: function() {
          if(this.totalTime >= 1){
            this.totalTime--;
          } else{
            this.totalTime = 0;
            this.resetTimer()
          }
        }
      },
      computed: {
        minutes: function() {
          const minutes = Math.floor(this.totalTime / 60);
          return this.padTime(minutes);
        },
        seconds: function() {
          const seconds = this.totalTime - (this.minutes * 60);
          return this.padTime(seconds);
        }
      }
})